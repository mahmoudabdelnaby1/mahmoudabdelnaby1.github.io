# Mahmoud Abdelnaby — Portfolio & Assistant Library

Bilingual English/Arabic professional portfolio and a public catalog of 140 reusable AI assistant prompts.

- Website: https://mahmoudabdelnaby1.github.io
- LinkedIn: https://eg.linkedin.com/in/mahmoudabdelnaby4
- English and Arabic portfolio interface; original assistant prompts are preserved in English.
- This static site does not host or run AI models.
- Removed from this release at the owner's request: Anime Aura Prompter, Anime Verse Prompto, Eco Sage, Grow With Grace.

Portfolio metrics were supplied by the profile owner. No testimonials or independent case studies are represented as verified.
