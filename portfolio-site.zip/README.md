# Mahmoud Abdelnaby — Portfolio & Assistant Library

A bilingual professional portfolio and searchable library of 140 practical AI assistant prompts spanning marketing, growth, analytics, content, design, and productivity.

- **Live portfolio:** https://mahmoudabdelnaby1.github.io
- **GitHub profile:** https://github.com/mahmoudabdelnaby1
- **LinkedIn:** https://eg.linkedin.com/in/mahmoudabdelnaby4

The portfolio presents experience across paid media, lead generation, e-commerce, analytics, web development, automation, and generative AI. Each assistant has a dedicated page with its prompt, intro, welcome message, category, and individual icon. The assistants are presented as prompt resources; this static site does not host or run AI models.
